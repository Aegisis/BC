const contractAddress = "0x5CccFaC2E04AB1934214E87e848b9862E4ff11Af"; // Replace with your deployed contract address
const contractABI = [
    {
        "inputs": [],
        "stateMutability": "nonpayable",
        "type": "constructor"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": false,
                "internalType": "string",
                "name": "candidate",
                "type": "string"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "voteCount",
                "type": "uint256"
            }
        ],
        "name": "Vote",
        "type": "event"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "",
                "type": "string"
            }
        ],
        "name": "c",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function",
        "constant": true
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "name": "cn",
        "outputs": [
            {
                "internalType": "string",
                "name": "",
                "type": "string"
            }
        ],
        "stateMutability": "view",
        "type": "function",
        "constant": true
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "name": "voters",
        "outputs": [
            {
                "internalType": "bool",
                "name": "",
                "type": "bool"
            }
        ],
        "stateMutability": "view",
        "type": "function",
        "constant": true
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "voter",
                "type": "address"
            }
        ],
        "name": "hasVoted",
        "outputs": [
            {
                "internalType": "bool",
                "name": "",
                "type": "bool"
            }
        ],
        "stateMutability": "view",
        "type": "function",
        "constant": true
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "caNm",
                "type": "string"
            }
        ],
        "name": "vote",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "canM",
                "type": "string"
            }
        ],
        "name": "getVoterC",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function",
        "constant": true
    },
    {
        "inputs": [],
        "name": "getWinner",
        "outputs": [
            {
                "internalType": "string",
                "name": "",
                "type": "string"
            }
        ],
        "stateMutability": "view",
        "type": "function",
        "constant": true
    }
]; // Use ABI from compiled contract

let web3;
let contract;

window.addEventListener("load", async () => {
    if (window.ethereum) {
        web3 = new Web3(window.ethereum);
        await window.ethereum.enable();
    } else {
        console.log("MetaMask not detected. Please install MetaMask.");
    }

    contract = new web3.eth.Contract(contractABI, contractAddress);
});


async function vote(can) {
    var canM = can;
    const accounts = await web3.eth.getAccounts();
    const voter = accounts[0];

    const hasVoted = await contract.methods.hasVoted(voter).call();

    if (hasVoted) {
        alert("You have already voted.");
        return;
    }

    contract.methods.vote(canM).send({
        from: voter
    })

    contract.events.Vote().on("data", () => {
        contract.methods.getVoterC(canM).call()
            .then((votes) => {
                document.getElementById(canM).innerText = `${votes}`;
            });
    })
};


async function checkResult() {
    const accounts = await web3.eth.getAccounts();

    contract.methods.getWinner()
        .call({ from: accounts[0] })
        .then((winner) => {
            document.getElementById("result").innerText = `${winner}`;
        });
}